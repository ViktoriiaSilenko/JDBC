package ua.lviv.lgs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Main {
	public static final String URL = "jdbc:mysql://localhost/logos";
	public static final String USER = "root";
	public static final String PASSWORD = "root";

	private static Connection conn;

	public static void main(String[] args) throws SQLException {
		// Class.forName("com.mysql.jdbc.Driver");

		try {
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		PreparedStatement ps = conn
				.prepareStatement("create table if not exists person"
						+ "(`id` int not null auto_increment, "
						+ "`name` varchar(40), `age` int, primary key (id))");
		ps.execute();
		
		ps = conn.prepareStatement("insert into person (name,age) values (?,?)");
		ps.setString(1, "Oleg");
		ps.setInt(2, 41);
		ps.execute();
		
		List<Person> list = new ArrayList<Person>();
		ResultSet res = ps.executeQuery("select * from person");
		while (res.next()) {
			list.add(new Person(res.getString(2), res.getInt(3)));
		}
		for (Person person : list) {
			System.out.println(person);
		}
		conn.close();
	}

}
